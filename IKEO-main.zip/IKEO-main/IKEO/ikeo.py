from biblioteque import *


afficher_tous_les_produits_ainsi_que_leurs_sites_de_production()    
produits_par_usine()
afficher_un_graphique_des_commandes_par_produits()
afficher_un_graphique_des_commandes_par_clients()